
import { ComponentIdentification, SecureComponentState, IBMiComponent } from "@halcyontech/vscode-ibmi-types/api/components/component";
import IBMi from '@halcyontech/vscode-ibmi-types/api/IBMi';
import { getCLCheckerCPPSrc } from './cppSource';
import { getCLCheckerUDTFSrc } from './udtfSource';
import { getComponentRegistry, getInstance } from '../../api/ibmi';
import { posix } from 'path';
import { ExtensionContext } from 'vscode';

export type SupportedLanguageId = 'cl' | 'bnd' | 'cmd';
export type CheckOption = '*CL' | '*CLLE' | '*CLP' | '*PDM' | '*BND' | '*CMD' | '*LIMIT';

const LANGUAGE_ID_TO_CHECKOPT: Record<SupportedLanguageId, CheckOption> = {
  'cl': '*CLLE',
  'bnd': '*BND',
  'cmd': '*CMD'
};

export interface ClSyntaxError {
  msgid: string,
  msgtext: string,
  cmdstring: string
}

export class CLSyntaxChecker implements IBMiComponent {
  static ID = "CLSyntaxChecker";
  static UDTF_NAME = 'CL_SYNTAX_CHECKER';
  static PGM_NAME = 'CLSYNCHECK';
  static CHECK_INTERVAL = 1500;
  static MAX_DOCUMENT_LENGTH = 32740;
  private readonly currentVersion = 2;
  private library: string | undefined;

  getIdentification(): ComponentIdentification {
    return { name: CLSyntaxChecker.ID, version: this.currentVersion } as any;
  }

  static async get(): Promise<CLSyntaxChecker | undefined> {
    const instance = getInstance();
    const connection = instance?.getConnection();
    return await connection?.getComponent<CLSyntaxChecker>(CLSyntaxChecker.ID);
  }

  async getRemoteState(connection: IBMi, installDirectory: string): Promise<SecureComponentState> {
    const library = this.getLibrary(connection);

    const udtfVersion = await CLSyntaxChecker.getVersionOf(connection, library!, CLSyntaxChecker.UDTF_NAME);
    if (udtfVersion < this.currentVersion) {
      return { status: `NeedsUpdate` };
    }

    return { status: `Installed` };
  }

  static registerComponent(context: ExtensionContext) {
    const clSyntaxChecker = new CLSyntaxChecker();
    const componentRegistry = getComponentRegistry();
    componentRegistry?.registerComponent(context, clSyntaxChecker);
  }

  async update(connection: IBMi, installDirectory: string): Promise<SecureComponentState> {
    return await connection.withTempDirectory(async (tempDir: string) => {
      const content = connection.getContent();
      const textEncoder = new TextEncoder();
      const library = this.getLibrary(connection);

      // Upload C++ source
      const cppPath = posix.join(tempDir, `${CLSyntaxChecker.PGM_NAME}.cpp`);
      const cppSource = getCLCheckerCPPSrc();
      const cppBytes = textEncoder.encode(cppSource);
      await content.writeStreamfileRaw(cppPath, cppBytes);

      // Create C++ module
      const createModule = `QSYS/CRTCPPMOD MODULE(${library}/${CLSyntaxChecker.PGM_NAME}) SRCSTMF('${cppPath}') DBGVIEW(*LIST) LANGLVL(*EXTENDED0X) OUTPUT(*PRINT)`;
      const createModuleResult = await connection.runCommand({
        command: createModule,
        noLibList: true
      });
      if (createModuleResult.code !== 0) {
        return { status: `Error` };
      }

      // Create C++ program
      const createProgram = `QSYS/CRTPGM PGM(${library}/${CLSyntaxChecker.PGM_NAME}) MODULE(${library}/${CLSyntaxChecker.PGM_NAME}) ACTGRP(*CALLER)`;
      const createProgramResult = await connection.runCommand({
        command: createProgram,
        noLibList: true
      });
      if (createProgramResult.code !== 0) {
        return { status: `Error` };
      }

      // Upload UDTF source
      const sqlPath = posix.join(tempDir, `${CLSyntaxChecker.UDTF_NAME}.sql`);
      const sqlSource = getCLCheckerUDTFSrc(library!, this.currentVersion);
      const sqlBytes = textEncoder.encode(sqlSource);
      await content.writeStreamfileRaw(sqlPath, sqlBytes);

      // Drop existing UDTF specific
      try {
        const dropUdtf = `DROP SPECIFIC FUNCTION ${library}.${CLSyntaxChecker.UDTF_NAME}`;
        const dropUdtfResult = await connection.runSQL(dropUdtf);
      } catch (error) {
        // Ignore error as UDTF may not exist
      }

      // Create UDTF
      const createUdtf = `QSYS/RUNSQLSTM SRCSTMF('${sqlPath}') COMMIT(*NONE) NAMING(*SYS)`;
      const createUdtfResult = await connection.runCommand({
        command: createUdtf,
        noLibList: true
      });
      if (createUdtfResult.code !== 0) {
        return { status: `Error` }
      }

      // Clean up
      try {
        // Remove temporary source stream files
        await connection.sendCommand({ command: `rm -rf ${cppPath}` });
        await connection.sendCommand({ command: `rm -rf ${sqlPath}` });

        // Remove intermediate module
        await connection.runCommand({
          command: `QSYS/DLTOBJ OBJ(${library}/${CLSyntaxChecker.PGM_NAME}) OBJTYPE(*MODULE)`,
          noLibList: true
        });
      } catch (error) { }

      return { status: `Installed` };
    });
  }

  reset?(): void | Promise<void> {
    // This is called when connecting to a new system.
    this.library = undefined;
  }

  async check(clStmt: string, languageId: SupportedLanguageId): Promise<ClSyntaxError[] | undefined> {
    const instance = getInstance();
    const connection = instance?.getConnection();

    if (!connection) {
      return undefined;
    }

    // Double up any single quotes for SQL compatibility
    const escapedStmt = clStmt.replace(/'/g, "''");

    // Run the UDTF
    const library = this.getLibrary(connection);
    const checkOpt = LANGUAGE_ID_TO_CHECKOPT[languageId] || '*CLLE';
    const cmd = [
      `select MSGID, MSGTEXT, CMDSTRING`,
      `from table(${library}.${CLSyntaxChecker.UDTF_NAME}('${escapedStmt}', CHECKOPT=>'${checkOpt}'))`
    ].join(" ");

    const results = await connection.runSQL(cmd);
    return results.map(result => ({
      msgid: result.MSGID,
      msgtext: result.MSGTEXT,
      cmdstring: result.CMDSTRING
    } as ClSyntaxError));
  }

  private getLibrary(connection: IBMi) {
    if (!this.library) {
      const config = connection?.getConfig();
      this.library = config?.tempLibrary.toUpperCase() || `ILEDITOR`;
    }

    return this.library;
  }

  static async getVersionOf(connection: IBMi, schema: string, name: string) {
    const [result] = await connection.runSQL(`select cast(LONG_COMMENT as VarChar(200)) LONG_COMMENT from qsys2.sysroutines where routine_schema = '${schema}' and routine_name = '${name}'`);
    if (result?.LONG_COMMENT) {
      const comment = String(result.LONG_COMMENT);
      const dash = comment.indexOf('-');
      if (dash > -1) {
        return Number(comment.substring(0, dash).trim());
      }
    }

    return -1;
  }
}