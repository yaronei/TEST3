/*
    Christian Larsen, 2025
    "RPG structure"
    commands/register-commands.ts
*/

import * as vscode from 'vscode';
import { DdsTreeProvider } from '../dspf-edit.providers/dspf-edit.providers';

import { changePosition } from './dspf-edit.change-position';
import { centerPosition } from './dspf-edit.center';
import { editConstant, addConstant } from './dspf-edit.edit-constant';
import { registerFieldCommands } from './dspf-edit.edit-field';
import { viewStructure } from './dspf-edit.view-structure';
import { copyRecord } from './dspf-edit.copy-record';
import { deleteRecord } from './dspf-edit.delete-record';
import { newRecord } from './dspf-edit.new-record';
import { addDisplaySize } from './dspf-edit.add-display-size';
import { goToLineHandler } from './dspf-edit.goto-line';
import { addButtons } from './dspf-edit.add-buttons';
import { addCommandsRecord } from './dspf-edit.add-commands-record';
import { addColor } from './dspf-edit.add-color';
import { addAttribute } from './dspf-edit.add-attribute';
import { addKeyCommand } from './dspf-edit.add-keys';
import { addValidityCheck } from './dspf-edit.add-validity-check';
import { editingKeywords } from './dspf-edit.add-editing-keywords';
import { addErrorMessage } from './dspf-edit.add-error-messages';
import { addIndicators } from './dspf-edit.add-indicators';
import { fillConstant } from './dspf-edit.fill-constant';
import { windowResize } from './dspf-edit.window-resize';
import { windowTitle } from './dspf-edit.window-title';
import { sortElements } from './dspf-edit.sort-elements';
import { copyField } from './dspf-edit.copy-field';
import { copyConstant } from './dspf-edit.copy-constant';
import { removeElement } from './dspf-edit.remove-element';
import { removeAttribute } from './dspf-edit.remove-attribute';
import { renameField, renameRecord } from './dspf-edit.rename';
import { moveConstantLeft1, moveConstantLeft5, moveConstantRight1, moveConstantRight5 } from './dspf-edit.move-constants';
import { moveFieldLeft1, moveFieldLeft5, moveFieldRight1, moveFieldRight5 } from './dspf-edit.move-fields';
import { previewRecord } from './dspf-edit.preview-record';
import { resolveReferencedFieldCommand, resolveAllReferencedFieldsCommand } from './dspf-edit.resolve-referenced-field';
import { PreviewColorsPanel } from '../dspf-edit.webview/dspf-edit.preview-colors-panel';
import { RecordPreviewPanel } from '../dspf-edit.webview/dspf-edit.record-preview-panel';
import { resetPreviewColors } from '../dspf-edit.utils/dspf-edit.preview-colors';

export const commands = [
    { name: 'viewStructure', handler: viewStructure, needsTreeProvider: true },
    { name: 'previewRecord', handler: previewRecord, needsTreeProvider: true },
    { name: 'addConstant', handler: addConstant, needsTreeProvider: false },
    { name: 'editConstant', handler: editConstant, needsTreeProvider: false },
    { name: 'registerFieldCommands', handler: registerFieldCommands, needsTreeProvider: false },
    { name: 'changePosition', handler: changePosition, needsTreeProvider: false },
    { name: 'centerPosition', handler: centerPosition, needsTreeProvider: false },
    { name: 'copyRecord', handler: copyRecord, needsTreeProvider: false },
    { name: 'deleteRecord', handler: deleteRecord, needsTreeProvider: false },
    { name: 'newRecord', handler: newRecord, needsTreeProvider: false },
    { name: 'addDisplaySize', handler: addDisplaySize, needsTreeProvider: false },
    { name: 'goToLine', handler: goToLineHandler, needsTreeProvider: false },
    { name: 'addButtons', handler: addButtons, needsTreeProvider: false },
    { name: 'addCommandsRecord', handler: addCommandsRecord, needsTreeProvider: false },
    { name: 'addColor', handler: addColor, needsTreeProvider: false },
    { name: 'addAttribute', handler: addAttribute, needsTreeProvider: false },
    { name: 'addKey', handler: addKeyCommand, needsTreeProvider: false },
    { name: 'addValidityCheck', handler: addValidityCheck, needsTreeProvider: false },
    { name: 'addEditingKeywords', handler: editingKeywords, needsTreeProvider: false },
    { name: 'addErrorMessage', handler: addErrorMessage, needsTreeProvider: false },
    { name: 'addIndicators', handler: addIndicators, needsTreeProvider: false },
    { name: 'fillConstant', handler: fillConstant, needsTreeProvider: false },
    { name: 'windowResize', handler: windowResize, needsTreeProvider: false },
    { name: 'windowTitle', handler: windowTitle, needsTreeProvider: false },
    { name: 'sortElements', handler: sortElements, needsTreeProvider: false },
    { name: 'copyField', handler: copyField, needsTreeProvider: false },
    { name: 'copyConstant', handler: copyConstant, needsTreeProvider: false },
    { name: 'removeElement', handler: removeElement, needsTreeProvider: false },
    { name: 'removeAttribute', handler: removeAttribute, needsTreeProvider: false },
    { name: 'renameField', handler: renameField, needsTreeProvider: false },
    { name: 'renameRecord', handler: renameRecord, needsTreeProvider: false },
    { name: 'moveConstantLeft1', handler: moveConstantLeft1, needsTreeProvider: false },
    { name: 'moveConstantLeft5', handler: moveConstantLeft5, needsTreeProvider: false },
    { name: 'moveConstantRight1', handler: moveConstantRight1, needsTreeProvider: false },
    { name: 'moveConstantRight5', handler: moveConstantRight5, needsTreeProvider: false },
    { name: 'moveFieldLeft1', handler: moveFieldLeft1, needsTreeProvider: false },
    { name: 'moveFieldLeft5', handler: moveFieldLeft5, needsTreeProvider: false },
    { name: 'moveFieldRight1', handler: moveFieldRight1, needsTreeProvider: false },
    { name: 'moveFieldRight5', handler: moveFieldRight5, needsTreeProvider: false },
    { name: 'resolveReferencedField', handler: resolveReferencedFieldCommand, needsTreeProvider: true },
    { name: 'resolveAllReferencedFields', handler: resolveAllReferencedFieldsCommand, needsTreeProvider: true }

];

/**
 * Register all commands defined
 * @param context - Context
 * @param treeProvider - Tree Provider
 * @param commands - List of commands to register
 */
export function registerCommands(
    context: vscode.ExtensionContext,
    treeProvider: DdsTreeProvider
) {
    commands.forEach(cmd => {
        if (cmd.needsTreeProvider) {
            (cmd.handler as (ctx: vscode.ExtensionContext, tp: DdsTreeProvider) => void)(context, treeProvider);
        } else {
            (cmd.handler as (ctx: vscode.ExtensionContext) => void)(context);
        };
    });

    context.subscriptions.push(
        vscode.commands.registerCommand('dspf-edit.filterTreeView', () => {
            treeProvider.showFilterMenu();
        }),

        vscode.commands.registerCommand('dspf-edit.showAllElements', () => {
            treeProvider.showAll();
        }),

        vscode.commands.registerCommand('dspf-edit.hideAllElements', () => {
            treeProvider.hideAll();
        }),

        vscode.commands.registerCommand('dspf-edit.toggleFields', () => {
            treeProvider.toggleVisibility('field');
        }),

        vscode.commands.registerCommand('dspf-edit.toggleConstants', () => {
            treeProvider.toggleVisibility('constant');
        }),

        vscode.commands.registerCommand('dspf-edit.reset-preview-colors', async () => {
            const resetAny = await resetPreviewColors();
            RecordPreviewPanel.refreshTheme();
            vscode.window.showInformationMessage(
                resetAny
                    ? 'DSPF Edit: preview colors reset to default.'
                    : 'DSPF Edit: preview colors were already at their default.'
            );
        }),

        vscode.commands.registerCommand('dspf-edit.configure-preview-colors', () => {
            PreviewColorsPanel.show();
        })

    );

};

