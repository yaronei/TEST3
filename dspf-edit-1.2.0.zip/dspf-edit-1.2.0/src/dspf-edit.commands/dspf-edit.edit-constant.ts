/*
    Christian Larsen, 2025
    "RPG structure"
    dspf-edit.edit-constant.ts
*/

import * as vscode from 'vscode';
import { DdsNode } from '../dspf-edit.providers/dspf-edit.providers';
import { fileSizeAttributes, fieldsPerRecords, getRecordSize } from '../dspf-edit.model/dspf-edit.model';
import { checkForEditorAndDocument, findEndLineIndex, applyWorkspaceEdit } from '../dspf-edit.utils/dspf-edit.helper';

// TYPE DEFINITIONS

/**
 * Information needed to create a new constant.
 */
export interface NewConstantInfo {
    text: string;
    row: number;
    column: number;
    recordName: string;
};

/**
 * Position information for a constant.
 */
interface ConstantPosition {
    row: number;
    column: number;
    recordName: string;
};

/**
 * Information about an existing constant.
 */
interface ExistingConstantInfo {
    text: string;
    row: number;
    column: number;
    lineIndex: number;
};

/**
 * Gets the maximum rows value from fileSizeAttributes
 */
function getMaxRows(): number {
    const maxRow1 = fileSizeAttributes.maxRow1 || 0;
    const maxRow2 = fileSizeAttributes.maxRow2 || 0;
    const maxRow = Math.max(maxRow1, maxRow2);
    return maxRow > 0 ? maxRow : 27;
};

/**
 * Gets the maximum columns value from fileSizeAttributes
 */
function getMaxCols(): number {
    const maxCol1 = fileSizeAttributes.maxCol1 || 0;
    const maxCol2 = fileSizeAttributes.maxCol2 || 0;
    const maxCol = Math.max(maxCol1, maxCol2);
    return maxCol > 0 ? maxCol : 132;
};

/**
 * Bounds a new constant's position can validly land in, for a given record. When the record is a
 * window, that's its own (typically smaller) content rectangle, not the whole file's declared
 * screen size; a non-window (base display) record uses the whole file's declared size.
 * @param recordName - The record to resolve bounds for
 */
function getPositionBounds(recordName: string): { maxRows: number; maxCols: number } {
    const size = getRecordSize(recordName);
    if (size?.source === 'window') {
        return { maxRows: size.rows, maxCols: size.cols };
    };
    return { maxRows: getMaxRows(), maxCols: getMaxCols() };
};

// COMMAND REGISTRATION FUNCTIONS

/**
 * Registers the edit constant command for DDS constants.
 * Allows users to modify the content of existing constants.
 * @param context - The VS Code extension context
 */
export function editConstant(context: vscode.ExtensionContext): void {
    context.subscriptions.push(
        vscode.commands.registerCommand("dspf-edit.edit-constant", async (node: DdsNode) => {
            await handleEditConstantCommand(node);
        })
    );
};

/**
 * Registers the add constant command for DDS files.
 * Allows users to add new constants to the DDS file.
 * @param context - The VS Code extension context
 */
export function addConstant(context: vscode.ExtensionContext): void {
    context.subscriptions.push(
        vscode.commands.registerCommand("dspf-edit.add-constant", async (node?: DdsNode) => {
            await handleAddConstantCommand(node);
        })
    );
};

// COMMAND HANDLERS

/**
 * Handles the edit constant command for an existing DDS constant.
 * @param node - The DDS node containing the constant to edit
 */
async function handleEditConstantCommand(node: DdsNode): Promise<void> {
    try {
        // Check for editor and document
        const { editor, document } = checkForEditorAndDocument();
        if (!document || !editor) {
            return;
        };

        const element = node.ddsElement;

        // Validate that the element is a constant
        if (element.kind !== "constant") {
            vscode.window.showWarningMessage("Only constants can be edited.");
            return;
        };

        // Get the current value without quotes for editing
        const currentValueNoQuotes = element.name.slice(1, -1);
        
        // Get new text from user
        const newText = await getConstantTextFromUser(
            `Set new text for ${element.name} (without quotes)`,
            currentValueNoQuotes,
            element.column
        );

        if (!newText) return;

        // Apply the constant update
        await updateExistingConstant(editor, element, newText);

    } catch (error) {
        console.error('Error editing constant:', error);
        vscode.window.showErrorMessage('An error occurred while editing the constant.');
    };
};

/**
 * Handles the add constant command to create a new DDS constant.
 * @param node - Optional DDS node for context (record or position reference)
 */
async function handleAddConstantCommand(node?: DdsNode): Promise<void> {
    try {
        // Check for editor and document
        const { editor, document } = checkForEditorAndDocument();
        if (!document || !editor) {
            return;
        };

        // Get constant properties from user
        const constantInfo = await getNewConstantInfo(editor, node);
        if (!constantInfo) return;

        // Apply the new constant
        await insertNewConstant(editor, constantInfo);

    } catch (error) {
        console.error('Error adding constant:', error);
        vscode.window.showErrorMessage('An error occurred while adding the constant.');
    };
};

// USER INPUT FUNCTIONS

/**
 * Gets constant text from user input with validation.
 * @param title - Title for the input dialog
 * @param defaultValue - Default value to show
 * @param column - Column position for length validation
 * @returns The entered text or null if cancelled
 */
export async function getConstantTextFromUser(
    title: string,
    defaultValue: string,
    column?: number
): Promise<string | null> {
    const newText = await vscode.window.showInputBox({
        title: title,
        value: defaultValue,
        validateInput: value => validateConstantText(value)
    });

    return newText || null;
};

/**
 * Gets complete information for a new constant from the user.
 * @param contextNode - Optional node for context
 * @returns Complete constant information or null if cancelled
 */
async function getNewConstantInfo(editor: vscode.TextEditor, contextNode?: DdsNode): Promise<NewConstantInfo | null> {
    // Get constant text
    const text = await getConstantTextFromUser(
        "Enter constant text (without quotes)",
        "",
        1 // Default column for validation
    );
    if (!text) return null;

    // Get position information
    const position = await getConstantPosition(editor, contextNode);
    if (!position) return null;

    return {
        text: text,
        row: position.row,
        column: position.column,
        recordName: position.recordName
    };
};

/**
 * Gets position information for a new constant.
 * @param contextNode - Optional node for context
 * @returns Position information or null if cancelled
 */
async function getConstantPosition(editor: vscode.TextEditor, contextNode?: DdsNode): Promise<ConstantPosition | null> {
    // If we have a record context, suggest positions within that record
    if (contextNode && contextNode.ddsElement.kind === 'record') {
        return await getPositionForRecord(editor, contextNode.ddsElement);
    };

    // Otherwise, ask for manual position entry
    return await getManualPosition();
};

/**
 * Gets position information when adding to a specific record.
 * @param recordElement - The record element
 * @returns Position information or null if cancelled
 */
async function getPositionForRecord(editor: vscode.TextEditor, recordElement: any): Promise<ConstantPosition | null> {
    // First ask if user wants relative or absolute positioning
    const positioningType = await vscode.window.showQuickPick(
        [
            { 
                label: "Absolute position", 
                description: "Enter specific row and column",
                value: "absolute" 
            },
            { 
                label: "Relative to existing constant", 
                description: "Position above or below an existing constant",
                value: "relative" 
            }
        ],
        {
            title: `Choose positioning method for record ${recordElement.name}`,
            placeHolder: "Select how to position the new constant"
        }
    );

    if (!positioningType) return null;

    if (positioningType.value === "relative") {
        return await getRelativePosition(editor, recordElement);
    } else {
        return await getAbsolutePositionForRecord(recordElement);
    }
};

/**
 * Gets relative position information based on existing constants.
 * @param recordElement - The record element
 * @returns Position information or null if cancelled
 */
async function getRelativePosition(editor: vscode.TextEditor, recordElement: any): Promise<ConstantPosition | null> {
    // Get existing constants in this record
    const existingConstants = await getExistingConstantsInRecord(recordElement.name, editor);
    
    if (existingConstants.length === 0) {
        vscode.window.showInformationMessage("No existing constants found in this record. Using absolute positioning.");
        return await getAbsolutePositionForRecord(recordElement);
    };

    // Show constants for selection
    const selectedConstant = await vscode.window.showQuickPick(
        existingConstants.map(constant => ({
            label: `${constant.text}`,
            description: `Row: ${constant.row}, Column: ${constant.column}`,
            detail: `Line: ${constant.lineIndex + 1}`,
            constant: constant
        })),
        {
            title: "Select reference constant",
            placeHolder: "Choose the constant to position relative to"
        }
    );

    if (!selectedConstant) return null;

    // Ask for relative position (above or below)
    const relativePosition = await vscode.window.showQuickPick(
        [
            { 
                label: "Below", 
                description: "Position the new constant below the selected one",
                value: "below" 
            },
            { 
                label: "Above", 
                description: "Position the new constant above the selected one",
                value: "above" 
            }
        ],
        {
            title: "Relative position",
            placeHolder: "Where should the new constant be positioned?"
        }
    );

    if (!relativePosition) return null;

    // Calculate the new position
    const referenceConstant = selectedConstant.constant;
    const newRow = relativePosition.value === "above" 
        ? referenceConstant.row - 1 
        : referenceConstant.row + 1;

    // Validate the new row position
    const { maxRows } = getPositionBounds(recordElement.name);
    if (newRow < 1 || newRow > maxRows) {
        vscode.window.showErrorMessage(`Cannot position constant at row ${newRow}. Row must be between 1 and ${maxRows}.`);
        return null;
    };

    // Use the same column as the reference constant
    return {
        row: newRow,
        column: referenceConstant.column,
        recordName: recordElement.name
    };
};

/**
 * Gets absolute position information for a record.
 * @param recordElement - The record element
 * @returns Position information or null if cancelled
 */
async function getAbsolutePositionForRecord(recordElement: any): Promise<ConstantPosition | null> {
    const bounds = getPositionBounds(recordElement.name);

    const row = await vscode.window.showInputBox({
        title: `Enter row position for constant in record ${recordElement.name}`,
        validateInput: value => validateRowInput(value, bounds.maxRows)
    });
    if (!row) return null;

    const column = await vscode.window.showInputBox({
        title: "Enter column position for constant",
        validateInput: value => validateColumnInput(value, bounds.maxCols)
    });
    if (!column) return null;

    return {
        row: parseInt(row, 10),
        column: parseInt(column, 10),
        recordName: recordElement.name
    };
};

/**
 * Gets position information through manual entry.
 * @returns Position information or null if cancelled
 */
async function getManualPosition(): Promise<ConstantPosition | null> {
    const recordName = await vscode.window.showInputBox({
        title: "Enter record name for the constant",
        validateInput: value => value.trim() === '' ? "Record name cannot be empty" : null
    });
    if (!recordName) return null;

    // Bounds depend on whether this record turns out to be a window — only knowable once its name
    // is in hand, hence resolved here rather than up front.
    const bounds = getPositionBounds(recordName.trim());

    const row = await vscode.window.showInputBox({
        title: "Enter row position for constant",
        validateInput: value => validateRowInput(value, bounds.maxRows)
    });
    if (!row) return null;

    const column = await vscode.window.showInputBox({
        title: "Enter column position for constant",
        validateInput: value => validateColumnInput(value, bounds.maxCols)
    });
    if (!column) return null;

    return {
        row: parseInt(row, 10),
        column: parseInt(column, 10),
        recordName: recordName.trim()
    };
};

/**
 * Gets existing constants in a specific record.
 * @param recordName - The record name to search in
 * @returns Array of existing constant information
 */
async function getExistingConstantsInRecord(recordName: string, editor : vscode.TextEditor): Promise<ExistingConstantInfo[]> {
    
    if (!editor) return [];

    const constants: ExistingConstantInfo[] = [];
    const document = editor.document;
    
    // Find record boundaries
    const recordInfo = fieldsPerRecords.find(r => r.record === recordName);
    if (!recordInfo) return [];

    // Scan through the record lines to find constants
    for (let lineIndex = recordInfo.startIndex; lineIndex <= recordInfo.endIndex; lineIndex++) {
        if (lineIndex >= document.lineCount) break;
        
        const line = document.lineAt(lineIndex);
        const constant = parseConstantFromLine(line.text, lineIndex);
        
        if (constant) {
            constants.push(constant);
        };
    };

    // Sort constants by row, then by column
    constants.sort((a, b) => {
        if (a.row !== b.row) return a.row - b.row;
        return a.column - b.column;
    });

    return constants;
};

/**
 * Parses a constant from a DDS line.
 * @param lineText - The line text to parse
 * @param lineIndex - The line index in the document
 * @returns Constant information or null if not a constant
 */
function parseConstantFromLine(lineText: string, lineIndex: number): ExistingConstantInfo | null {
    // DDS constant format: positions 7-38 are name/blank, 39-41 is row, 42-44 is column, 45+ is constant value
    if (lineText.length < 45) return null;
    
    // Check if this is a constant line (starts with "     A" and has quotes in the constant area)
    if (!lineText.startsWith('     A')) return null;
    
    const constantArea = lineText.substring(44); // From position 45 onwards
    if (!constantArea.includes("'")) return null;
    
    // Extract row and column
    const rowStr = lineText.substring(38, 41).trim();
    const colStr = lineText.substring(41, 44).trim();
    
    if (!rowStr || !colStr) return null;
    
    const row = parseInt(rowStr, 10);
    const column = parseInt(colStr, 10);
    
    if (isNaN(row) || isNaN(column)) return null;
    
    // Extract the constant text (find the content between quotes)
    const quoteStart = constantArea.indexOf("'");
    if (quoteStart === -1) return null;
    
    let text = '';
    let i = quoteStart + 1;
    let inQuotes = true;
    
    // Handle multi-line constants by continuing to next lines if needed
    while (inQuotes && i < constantArea.length) {
        if (constantArea[i] === "'") {
            inQuotes = false;
        } else {
            text += constantArea[i];
        }
        i++;
    };
    
    // If we didn't find the closing quote, it might be a multi-line constant
    if (inQuotes) {
        text = constantArea.substring(quoteStart + 1);
        // For simplicity, we'll truncate multi-line constants in the display
        if (text.length > 20) {
            text = text.substring(0, 20) + '...';
        };
    };

    return {
        text: text || 'Constant',
        row: row,
        column: column,
        lineIndex: lineIndex
    };
};

// VALIDATION FUNCTIONS

/**
 * Validates constant text input.
 * @param value - The text value to validate
 * @param column - Optional column position for length validation
 * @returns Error message or null if valid
 */
function validateConstantText(value: string): string | null {
    if (value === '') {
        return "The constant text cannot be empty.";
    };

    return null;
};

/**
 * Validates row input.
 * @param value - The row value to validate
 * @param maxRows - Highest valid row (the record's window content, or the file's declared size)
 * @returns Error message or null if valid
 */
function validateRowInput(value: string, maxRows: number): string | null {
    const num = parseInt(value, 10);
    if (isNaN(num) || num < 1 || num > maxRows) {
        return `Row must be a number between 1 and ${maxRows}.`;
    }
    return null;
};

/**
 * Validates column input.
 * @param value - The column value to validate
 * @param maxCols - Highest valid column (the record's window content, or the file's declared size)
 * @returns Error message or null if valid
 */
function validateColumnInput(value: string, maxCols: number): string | null {
    const num = parseInt(value, 10);
    if (isNaN(num) || num < 1 || num > maxCols) {
        return `Column must be a number between 1 and ${maxCols}.`;
    }
    return null;
};

// CONSTANT UPDATE FUNCTIONS

/**
 * Updates an existing constant in the DDS file.
 * @param editor - The active text editor
 * @param element - The constant element to update
 * @param newText - The new text for the constant
 */
export async function updateExistingConstant(
    editor: vscode.TextEditor,
    element: any,
    newText: string
): Promise<boolean> {
    const newValue = `'${newText}'`;
    const uri = editor.document.uri;
    const workspaceEdit = new vscode.WorkspaceEdit();

    const endLineIndex = findEndLineIndex(editor.document, element.lineIndex);
    const fitsInSingleLine = newValue.length <= 36;

    if (fitsInSingleLine) {
        await updateConstantSingleLine(workspaceEdit, uri, editor, element, newValue, endLineIndex);
    } else {
        await updateConstantMultiLine(workspaceEdit, uri, editor, element, newValue, endLineIndex);
    };

    return applyWorkspaceEdit(workspaceEdit, 'update the constant');
};

/**
 * Inserts a new constant into the DDS file.
 * @param editor - The active text editor
 * @param constantInfo - Information about the new constant
 */
export async function insertNewConstant(editor: vscode.TextEditor, constantInfo: NewConstantInfo): Promise<boolean> {
    const newValue = `'${constantInfo.text}'`;
    const uri = editor.document.uri;
    const workspaceEdit = new vscode.WorkspaceEdit();

    // Find the appropriate insertion point (end of file or before next record)
    const insertionLine = findConstantInsertionPoint(editor, constantInfo.recordName);
    
    const fitsInSingleLine = newValue.length <= 36;
    const constantLines = fitsInSingleLine 
        ? createSingleLineConstant(constantInfo, newValue)
        : createMultiLineConstant(constantInfo, newValue);

    if (insertionLine >= editor.document.lineCount) {
        workspaceEdit.insert(uri, new vscode.Position(insertionLine, 0), '\n');        
    };
    workspaceEdit.insert(uri, new vscode.Position(insertionLine, 0), constantLines.join('\n'));
    if (insertionLine < editor.document.lineCount) {
        workspaceEdit.insert(uri, new vscode.Position(insertionLine, 0), '\n');        
    };

    if (!(await applyWorkspaceEdit(workspaceEdit, 'add the constant'))) {
        return false;
    };
    await vscode.commands.executeCommand('cursorRight');
    await vscode.commands.executeCommand('cursorLeft');

    vscode.window.showInformationMessage(`Constant added successfully.`);
    return true;
};

// LINE CREATION FUNCTIONS

/**
 * Updates a constant that fits in a single line.
 * @param workspaceEdit - The workspace edit to apply changes to
 * @param uri - The document URI
 * @param element - The constant element
 * @param newValue - The new constant value
 * @param endLineIndex - The end line index of the current constant
 */
async function updateConstantSingleLine(
    workspaceEdit: vscode.WorkspaceEdit,
    uri: vscode.Uri,
    editor: vscode.TextEditor,
    element: any,
    newValue: string,
    endLineIndex: number
): Promise<void> {
    const firstLine = editor.document.lineAt(element.lineIndex).text;
    const updatedLine = firstLine.substring(0, 44) + newValue;

    workspaceEdit.delete(uri, new vscode.Range(
        element.lineIndex, 0, 
        element.lineIndex + endLineIndex - element.lineIndex + 1, 0
    ));

    if (element.lineIndex >= editor.document.lineCount) {
        workspaceEdit.insert(uri, new vscode.Position(element.lineIndex, 0), '\n');        
    };
    workspaceEdit.insert(uri, new vscode.Position(element.lineIndex, 0), updatedLine);
    if (element.lineIndex < editor.document.lineCount - 1) {
        workspaceEdit.insert(uri, new vscode.Position(element.lineIndex, 0), '\n');        
    };

};

/**
 * Updates a constant that spans multiple lines.
 * @param workspaceEdit - The workspace edit to apply changes to
 * @param uri - The document URI
 * @param element - The constant element
 * @param newValue - The new constant value
 * @param endLineIndex - The end line index of the current constant
 */
async function updateConstantMultiLine(
    workspaceEdit: vscode.WorkspaceEdit,
    uri: vscode.Uri,
    editor: vscode.TextEditor,
    element: any,
    newValue: string,
    endLineIndex: number
): Promise<void> {
    const firstLine = editor.document.lineAt(element.lineIndex).text;
    const updatedLines = createMultiLineConstantFromBase(firstLine, newValue);

    workspaceEdit.delete(uri, new vscode.Range(
        element.lineIndex, 0, 
        element.lineIndex + endLineIndex - element.lineIndex + 1, 0
    ));

    if (element.lineIndex >= editor.document.lineCount) {
        workspaceEdit.insert(uri, new vscode.Position(element.lineIndex, 0), '\n');        
    };
    workspaceEdit.insert(uri, new vscode.Position(element.lineIndex, 0), updatedLines.join('\n'));
    if (element.lineIndex < editor.document.lineCount - 1) {
        workspaceEdit.insert(uri, new vscode.Position(element.lineIndex, 0), '\n');        
    };
};

/**
 * Creates a single line constant definition.
 * @param constantInfo - Information about the constant
 * @param value - The constant value with quotes
 * @returns Array containing the single line
 */
function createSingleLineConstant(constantInfo: NewConstantInfo, value: string): string[] {
    const formattedRow = String(constantInfo.row).padStart(3, ' ');
    const formattedCol = String(constantInfo.column).padStart(3, ' ');
    const line = `     A` + ' '.repeat(32) + `${formattedRow}${formattedCol}${value}`;
    return [line];
};

/**
 * Creates a multi-line constant definition.
 * @param constantInfo - Information about the constant
 * @param value - The constant value with quotes
 * @returns Array containing all lines for the constant
 */
function createMultiLineConstant(constantInfo: NewConstantInfo, value: string): string[] {
    const formattedRow = String(constantInfo.row).padStart(3, ' ');
    const formattedCol = String(constantInfo.column).padStart(3, ' ');
    const baseLine = `     A` + ' '.repeat(32) + `${formattedRow}${formattedCol}`;
    
    return createMultiLineConstantFromBase(baseLine, value);
};

/**
 * Creates multi-line constant content from a base line and value.
 * @param baseLine - The base line format
 * @param value - The constant value
 * @returns Array of lines for the multi-line constant
 */
function createMultiLineConstantFromBase(baseLine: string, value: string): string[] {
    const lines: string[] = [];
    let remainingText = value;
    
    // First line
    const firstChunk = remainingText.substring(0, 35);
    remainingText = remainingText.substring(35);
    const firstLine = baseLine.substring(0, 44) + firstChunk.padEnd(35, ' ') + '-';
    lines.push(firstLine);

    // Continuation lines
    while (remainingText.length > 0) {
        const nextChunk = remainingText.substring(0, 35);
        remainingText = remainingText.substring(35);
        
        const isLastChunk = remainingText.length === 0;
        const continuationChar = isLastChunk ? ' ' : '-';
        const contLine = '     A' + ' '.repeat(38) + nextChunk.padEnd(35, ' ') + continuationChar;
        lines.push(contLine);
        
        if (isLastChunk) {
            break;
        };
    };

    return lines;
};

// UTILITY FUNCTIONS

/**
 * Finds the appropriate insertion point for a new constant.
 * @param editor - The active text editor
 * @param recordName - The record name to insert the constant into
 * @returns The line number where the constant should be inserted
 */
function findConstantInsertionPoint(editor: vscode.TextEditor, recordName: string): number {
    // The constant must be inserted in the last line of the record (in the DDS source file)
    const recordInfo = fieldsPerRecords.find(r => r.record === recordName);
    if (!recordInfo) {
        return 0;
    }
    const recordLineEnd = recordInfo.endIndex + 1;

    return recordLineEnd;
};
