# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## [Unreleased]

- More DDS features and improvements planned.
- Bug fixes and stability enhancements.

## [1.13.1] - 2026-10-18
### Changed
- Screen Preview: what is selected (for example `3 fields/constants selected`, or a field's name, length and position) now shows to the right of the **Indicators** toggle, on the same row, instead of on the button row. The buttons no longer move to a row of their own when something is selected, so selecting or deselecting no longer moves the screen up or down. A long text is cut short with `…`; hovering it shows it whole.

### Fixed
- Screen Preview: right-clicking an element of a multi-selection opened **⋮ Actions** for the whole group, but the selection was reduced to that one element as soon as the mouse button was released. The whole group now stays selected.
- Screen Preview: with **⬚ Area** on, right-clicking an element of the selection replaced it with only that element, so **⋮ Actions** didn't offer **Align...**. Right-clicking no longer changes the selection, and **Align...** is offered for everything the rectangle selected.
- Screen Preview: on macOS, `Ctrl`+click, used to add an element to the selection, could also open the **⋮ Actions** menu, since macOS treats it as a right-click. It now only changes the selection.

## [1.13.0] - 2026-10-18
### Added
- Screen Preview: select fields and constants by dragging a rectangle over them. Turn on **⬚ Area** in the toolbar, then drag anywhere on the screen: every field and constant the rectangle touches is selected, without having to cover it whole. Hold `Ctrl`/`Cmd` while dragging to add them to the current selection, and press `Escape` while dragging to cancel and get back the previous one.
  - Only the record being previewed is selected: dimmed overlays and elements that aren't visible are left out.
  - While **⬚ Area** is on, clicking an element doesn't select or move it, and the resize handles don't show, so nothing is moved by accident. Right-clicking an element that is part of the selection still opens **⋮ Actions** for the whole selection.
  - Turning it on clears the current selection. Turning it off keeps what the rectangle selected, ready to be moved, aligned or deleted.
  - Inside a window the rectangle works too; the window is moved by dragging its border.
- Screen Preview: see where the elements that aren't visible are. Turn on **◌ Hidden** in the toolbar to show, as a dotted outline with faded text, every field and constant that isn't on the screen right now: the ones conditioned on indicators that are off, and the ones with an active `DSPATR(ND)`. Hovering one says why it's hidden, for example `shown on 61 N62`, or `DSPATR(ND)`.
  - Which ones are hidden follows the **Indicators** being simulated: turning on indicator 61 shows the elements conditioned on 61 normally, and hides the ones conditioned on `N61`.
  - Where a hidden element shares its place with a visible one, as an alternate on `61` / `N61` usually does, only its outline is drawn, so the visible one stays readable.
  - Elements hidden by their indicators can't be selected. One with `DSPATR(ND)` can still be clicked, as before.

### Fixed
- Screen Preview: clicking a field or constant brought back the Side Bar with the DSPF Structure view, even after hiding it with `Ctrl`/`Cmd`+`B` to work with the preview alone. The view is now left as it is. The clicked element is selected in it the next time it is shown.
- Screen Preview: clicking the second or a later line of a field that spans several lines (`CNTFLD()`, or a field too long for its line) could move the field as soon as the mouse moved by one pixel, as if it had been dragged. It now stays where it is unless it's really dragged.

## [1.12.0] - 2026-10-17
### Added
- Screen Preview: align several selected fields and constants. With more than one selected, the **⋮ Actions** menu has **Align...**, which then asks how to align them: **Left**, **Center** or **Right**. They line the elements up within the columns they already cover between them: left moves each one to the leftmost start column, right moves each one so it ends on the rightmost end column, and center centers each one between those two columns. Each element keeps its own row, and the whole change is a single undo step. Elements that share a row can't be aligned, since one would end up on top of the other; and a referenced field whose real length isn't known yet can only be aligned to the left.
- Screen Preview: align a window on the screen, horizontally and vertically. The window's **⋮** menu has **Align...**, which asks for the direction, horizontally or vertically, and then where: left, center or right, or top, center or bottom. The one the window already has is marked "current". Only the window's position on that axis changes; its size and its position on the other axis stay as they are. A window is never placed on row 1 and column 1 at the same time, the same as when dragging it.

### Fixed
- Screen Preview: **center horizontally** on a window left it 2 columns to the right of center. It didn't count the border, which adds 2 columns on each side of the window's content: a 40-column window on an 80-column screen ended up with 20 columns free on its left and 16 on its right. It now leaves 18 on each side.

## [1.11.0] - 2026-10-11
### Added
- Screen Preview: the user-defined edit codes, `EDTCDE(5)` to `EDTCDE(9)`, are now previewed. Their editing is not part of DDS: it lives on each IBM i, in the edit descriptions `QEDIT5` to `QEDIT9`. **Fetch from IBM i**, in the **Decimal Format** section of the Configuration panel, now reads them along with `QDECFMT`, and the message it shows says which codes were read. A field using one of them then shows as STRSDA shows it, for example `9,999.99CR` for a 6,2 field with the IBM-supplied `EDTCDE(5)`. These codes do not follow the decimal format setting, since each edit description has its own decimal point and separators. **Reset to Default** forgets them. Until they are fetched, a field with one of these codes previews with no editing, as before. Tested on IBM i 7.5.

### Changed
- Attributes and Colors: on a field or constant that already has some, **Attributes** and **Colors** now open a list of them, each with the indicators that condition it, instead of asking whether to add more, replace all or remove all. Each row has a button to change its indicators (✏️) and one to remove it (🗑️); **Add attributes...** / **Add colors...** adds more, and **Remove all** clears them.
  - Changing the indicators of an attribute or color opens the same menu a field or constant has in **Indicators**: up to nine indicators per condition, and several conditions joined with OR. Before, an attribute or color could only get up to three indicators, and no OR.
  - Indicators condition a whole source line. So an attribute or color that shares its line with something else (the field's own line, another keyword, or a keyword with several attributes such as `DSPATR(UL HI)`) is first moved to a line of its own, keeping the condition it had.
  - Removing one attribute of a keyword that holds several leaves the others in place.

### Fixed
- Indicators on an attribute of a field (from the attribute's node in the Schema Tree) always treated it as written on the field's own line, even when it was on a line of its own: it asked to move it, and left a line with only the old indicators behind. It now opens the indicators menu directly, with AND and OR conditions, as it already did for a constant's attributes.
- Removing an attribute or color whose condition spans several lines (more than three indicators, or OR conditions) left those extra indicator lines in the source, where they would condition whatever came next. They are now removed with it.
### Fixed
- Screen Preview: an input-capable field (usage `I` or `B`) with `EDTCDE()` previewed with no editing at all: no thousands separators, no sign, no date separators and no currency symbol. STRSDA shows it edited, the same as an output field, and so does the preview now. A 13,2 `B` field with `EDTCDE(M)` shows `99999999999,99-` instead of `99999999999,99`, and a 6,2 `B` field shows `9.999,99-` with `EDTCDE(J)`, `9.999,99CR` with `EDTCDE(A)`, `-9.999,99` with `EDTCDE(N)`, `$9.999,99-` with `EDTCDE(J $)` and `99-99-99` with `EDTCDE(Y)`. This undoes a change made in an earlier version, which had it the other way round.
- Screen Preview: an input-capable field with decimals and `EDTCDE(Z)` showed a decimal point. `EDTCDE(Z)` never shows one: a 6,2 `B` field now previews as `999999`, as in STRSDA.

## [1.10.0] - 2026-10-02
### Added
- Screen Preview: overlay several records at once ([#89](https://github.com/christianlarsen/dspf-edit/discussions/89)). The **Overlay** dropdown is now a list of checkboxes, with a filter box when the file has more than 8 records, so you can show, for example, a header, a footer and a "no records" format behind the record being previewed. Overlays are drawn dimmed behind it, in source order, each over the ones before it.
- Screen Preview: checked overlays stay checked when switching to another record of the same file, and are cleared when previewing another file.
- Screen Preview: a subfile's other half (the detail record while previewing its `SFLCTL`, and the other way round) now appears checked in the Overlay list instead of being shown with no way to turn it off. Checking a subfile record as an overlay also brings its other half. Both halves always go together; to see one without the other, turn off the new setting below.
- Screen Preview: the record named in `WINDOW(record-name)` is always shown, checked and locked in the Overlay list, since the window is built from it (its title, footer text...). That applies to the record being previewed and to its overlays.
- Configuration panel: new **Preview Overlay** section with two settings, both on by default:
  - **Show a subfile's detail and control records together**: turn it off to preview a subfile record without its other half, and check it yourself when you want it.
  - **Keep checked overlays when switching to another record**: turn it off to start each record with only its subfile pair and window owner.

- Column ruler ([#94](https://github.com/christianlarsen/dspf-edit/issues/94)): while editing DDS source, shows the format line `.....AAN01N02N03T.Name++++++RLen++TDpBLinPosFunctions+++…` above the line the cursor is on, and outlines each column area of that line, highlighting the one the cursor is in. Hovering an area shows its name and positions. It helps spot values typed into the wrong columns, like a usage `O` that ended up in the decimal positions. Works like the fixed-format RPG ruler of vscode-rpgle. Off by default: turn it on with `Shift+F4`, from the new **Source Editor** section of the Configuration panel, or with **Show/Hide Column Ruler** in the Command Palette.
- Screen Preview: when the previewed record, or one of its overlays, has referenced fields still waiting to be resolved, a warning icon (⚠) shows in front of the screen size. Hovering it says how many are pending. Until they are resolved their size, and the position of anything placed after them with `+n`, is not final.
- The extension now starts when a DDS display file is opened, instead of waiting for the DSPF Structure view to be opened, so the column ruler is there from the start.

### Changed
- Screen Preview: double-clicking a dimmed overlay to switch to it now picks the record whose field or constant is under the pointer. On an empty spot where several overlays overlap, the one drawn on top wins, instead of the first one in the file.
- Screen Preview: a referenced field that has been resolved now shows in its normal color, as STRSDA shows it. The referenced field marker color (orange by default) is only used for fields still waiting to be resolved. Before, a resolved field with no `COLOR()` or `DSPATR()` of its own kept the marker color.

### Fixed
- A field or constant positioned with `+n` right after a referenced field ([#97](https://github.com/christianlarsen/dspf-edit/issues/97)) was placed as if the referenced field were 0 long, on top of it or right next to it, even after resolving it. It now counts from the end of the referenced field, using its real length once resolved. The Schema Tree and the Screen Preview are updated as soon as the field is resolved. While it is still pending, the 1-character marker shown in the preview is counted.
- Screen Preview: the function-key legend only showed keys coded with a response indicator and a text, such as `CF03(03 'Exit')` or `HELP(01 'Help')`. Keys coded as `CF03`, `CF03(03)`, `HELP` or `HELP(83)`, which are just as valid, were missing, so a file using only those showed no legend at all ([#97](https://github.com/christianlarsen/dspf-edit/issues/97)). All three forms now show. `ROLLUP` and `ROLLDOWN`, the older names of `PAGEDOWN` and `PAGEUP`, show as **Page Down** and **Page Up** too.

## [1.9.0] - 2026-09-28
### Added
- File-level `REF` keyword support ([#91](https://github.com/christianlarsen/dspf-edit/issues/91)):
  - New **Reference File** option on the file node of the Schema Tree adds, changes or removes the file's `REF`. It asks for the library (optional, `*LIBL` or `*CURLIB` allowed), the file and the record format (optional), and writes the keyword right after `DSPSIZ`, where STRSDA puts it. Changing or removing it makes the document's referenced fields pending again, so they are resolved against the new file.
  - Hovering a referenced field in the Schema Tree shows where its definition comes from: the file in its own `REFFLD()`, the file-level `REF`, or a field earlier in the same source.
- Add Field: referenced fields now have their own entries in the first field kind list, instead of being under "More options...":
  - **Referenced from REF file** (only when the file has a `REF`) asks only for the referenced field's name. With the same name as the new field, only the `R` in position 29 is written, with no `REFFLD()`, as DDS allows. With a different name, `REFFLD(name)` is written with no file.
  - **Referenced from another file** asks for library, file, field and record format, as before.
  - **Referenced from this source** lists the fields of the record and of the records before it to pick from, and writes `REFFLD(field *SRC)`, qualified with the record format when the field is in another record.
- Add Field: hidden fields now have their own entries in the first field kind list, **Alphanumeric — Hidden** and **Numeric — Hidden**, instead of being under "More options...". They ask only for the length (or digits and decimals) and no position, and are written the way STRSDA writes them, e.g. `10A  H` and `4S 0H`.
- Resolving referenced fields: a field referencing another field of the same source is now resolved locally, without an IBM i connection. That's `REFFLD(field *SRC)`, and also `REFFLD(field)` with no file when the file has no `REF`, which DDS treats as `*SRC`. As DDS requires, the referenced field must come before the referencing one. If it is itself a referenced field, it must be resolved first; Resolve All handles them in source order.
- Resolving referenced fields: a referenced field's own length, decimal positions or data type now override the referenced field's, as DDS defines. A value such as `12` replaces it, `+4` or `-2` increases or decreases it, and changing the data type to character drops the decimal positions. These are applied on top of the resolved definition, so changing them in the source doesn't require resolving the field again.

### Fixed
- Resolving referenced fields: a `REF` naming a record format, e.g. `REF(LIB/FILE1 RECORD2)`, was not recognized, so fields relying on it could not be resolved.
- Referenced fields with a relative length, e.g. `+7` or `-2` in positions 30-34, were read as a length of 7 or -2.
- Add Field: a fully qualified `REFFLD(format/field library/file)` too long for positions 45-80 was written past position 80. The file now goes on a continuation line.
- Add Field, "More options...": pressing Esc when asked for the length didn't cancel. The field was added anyway with a length of 10.
- Add Field, "More options...": a message field (usage `M`) could be given any data type. DDS only allows character, so now only its length is asked, and the `M` usage isn't offered in a subfile record, where DDS doesn't allow it.
- Add Field, "More options...": a program-to-system field (usage `P`) offered date, time and timestamp types, which DDS doesn't allow for it.
- Add Field and Edit Field: a numeric field could be given up to 999 digits. The DDS maximum is 63.
- Schema Tree: hidden (`H`), message (`M`) and program-to-system (`P`) fields offered options that don't apply to a field that is never displayed: Center, Change Position, Colors, Attributes, validity checks, editing keywords and error messages. They are no longer offered for these fields. DDS only allows `ALIAS`, `INDTXT`, `OVRDTA`, `REFFLD` and `TEXT` on message and program-to-system fields, and a hidden field has no position and is neither input- nor output-capable.
- Resolving referenced fields: a `REF` coded at record level was used for the fields of that record. DDS only allows `REF` at file level, so it is now ignored there, as the compiler would reject it.

## [1.8.2] - 2026-09-26
### Fixed
- Resolving referenced fields on IBM i ([#90](https://github.com/christianlarsen/dspf-edit/issues/90)): a field's `REFFLD()` was only read when coded on the field's own definition line. If it was on a separate line below, the reference fell back to the field's own name and could not be found. `REFFLD()` is now read wherever it appears among the field's keywords.
- Resolving referenced fields on IBM i: a `REFFLD()` or `REF()` qualified with `*LIBL` (e.g. `REFFLD(ARTDESC *LIBL/ARTICLES)`) never found the field, because `*LIBL` was looked up as if it were a library name.
- Resolving referenced fields on IBM i: when no library was given, the file was looked up in every library on the system, so with the same file in several libraries (e.g. development and production) any of them could be used. It is now looked up only in the active Code for i connection's current library and then its library list, in that order, and the first library that has it is used, as the real library list does. `*LIBL` behaves the same as no library, and `*CURLIB` uses only the current library.
- Keywords continued onto the next source line with a plus sign (`+`) were not joined, only those using a minus sign (`-`) were. A `WDWBORDER((*COLOR WHT) (*DSPATR +` continued as `RI) ...` on the next line was split in two, so the Screen Preview showed the window border incorrectly. Both continuation characters are now handled as DDS defines them: `-` continues at position 45 of the next line, keeping its leading blanks, and `+` continues at its first non-blank character. This also applies to multi-line constants and to editing or removing keywords that span several lines.
- A trailing `-` followed by blanks was not always removed when joining a continued keyword.
- Screen Preview: a `DSPATR()` with more than one attribute, such as `DSPATR(UL HI)`, showed none of them. DDS allows it, and it is the same as coding `DSPATR(UL)` and `DSPATR(HI)` separately. Each attribute now shows.
- Add Attribute: the current attributes list, "Remove all" and "Replace all" ignored a `DSPATR()` with more than one attribute. It is now listed once per attribute and removed as a whole.
- Commands run from the tree that depend on the display size, such as Add Buttons, Center and Change Window Title, asked which size to use even when the Screen Preview was open with a size selected. They now use the preview's size and only ask when it's closed.
- When editing a keyword per display size (e.g. moving a window while previewing `*DS4`) splits it into one line per size, the unconditioned primary-size line is now always written first, followed by the secondary size's conditioned line, instead of the other way round. A shared line that already had a condition no longer carries it over to the primary-size line, where DDS doesn't allow it.
- Screen Preview: a window with two `WDWTITLE` keywords, for example a title centered on the top border and `*BOTTOM *RIGHT` for a function-key hint, showed only the first one. Both are now drawn, one per border. When more than one `WDWTITLE` targets the same border, their parameters are combined and the first one wins for a repeated parameter, as the DDS reference describes.

## [1.8.1] - 2026-09-22
### Fixed
- A constant with a color or display attribute (e.g. `COLOR(RED)`, `DSPATR(UL)`) written on the same source line as its own text could show incorrectly in the Screen Preview, and editing that constant's text could erase the color/attribute entirely. Fixed.
- Add Attribute / Add Color: "Remove all" and "Replace all" could leave that same kind of color/attribute in place on a constant instead of clearing it. Now detected and removed correctly.

## [1.8.0] - 2026-09-17
### Added
- Screen Preview: fields carrying `ERRMSGID()` are now recognized the same way as `ERRMSG()` — shown in reverse image while active, with the message line showing a placeholder naming the message ID and file (its real text lives in an external message file this extension can't read).
- Screen Preview: `HELP()`, `PAGEDOWN()`, and `PAGEUP()` now show in the function-key legend, labeled **Help**, **Page Up**, and **Page Down** — they're dedicated keyboard keys rather than a numbered `Fnn` slot, so they're listed after the numbered keys instead of trying to fit an `Fnn` label that doesn't apply to them.
- Screen Preview: a field with an active `DFTVAL('value')` now previews with that literal text instead of a generic placeholder, matching what IBM i itself displays on the first output operation.
- Screen Preview: a `T` (time) field now previews with its digit positions and separator laid out per its `TIMFMT()`/`TIMSEP()` (`*HMS`, `*ISO`, `*USA`, `*EUR`, `*JIS`) instead of a plain run of digits with no separators.

### Fixed
- Screen Preview: a field too long to fit between its start column and the record's (or window's) right edge, with no `CNTFLD()` of its own, now auto-wraps across multiple rows matching real DDS/STRSDA — filling out the rest of the starting line, then continuing at column 1 using the full line width — instead of rendering as a single run past the edge.

## [1.7.0] - 2026-09-16
### Added
- A **Change Input Default** command on records and at file level, managing the parameterless form of `CHGINPDFT` — removes the automatic underline input-capable fields otherwise get by default. If the file already has it at file level, the record-level command warns you before offering to add/remove its own. The Screen Preview already reads this keyword: an input-capable field no longer forces its underline on when `CHGINPDFT` is in effect for it, unless the field carries its own `DSPATR(UL)`, which always takes priority.
- Edit Field can now also change a field's kind — alphanumeric ↔ numeric — not just its name and size. Switching kind writes the type column the same way the quick "Add Field" flow does (blank for alphanumeric; `S`, or `Y` when it has decimals, for numeric). If the switch would leave keywords that no longer apply (`EDTCDE`/`EDTWRD`/`EDTMSK` need a numeric field; `CHECK(LC)`/`LOWER` need a character one), a confirmation lists exactly what will be removed before anything is changed.
- Screen Preview: pressing `Delete`/`Backspace` with one or more fields/constants selected deletes them directly — same confirmation dialog as the "⋮ Actions" menu's Delete, without having to open it first.
- Screen Preview: double-clicking a dimmed background record — an SFL/SFLCTL auto-paired header or detail, the manual overlay, or a shared window's owner — switches the preview to that record, the same as picking it in the tree. Works anywhere across the rows the background occupies, not just directly on one of its fields/constants.
- Screen Preview: right-clicking a field or constant now opens the same "⋮ Actions" menu instead of the browser's native context menu (Cut/Copy/Paste), which was never useful there. Right-clicking an item that isn't already selected selects it first (replacing the current selection); right-clicking one already part of a multi-selection keeps the whole group.

## [1.6.0] - 2026-09-12
### Added
- A **Preview (DSPF-edit)** CodeLens above each record's `R` line in the DDS source, opening DSPF-edit's own Screen Preview for that record — useful when another extension (e.g. IBM i Renderer) already contributes its own "Preview" CodeLens on the same line, since a CodeLens command from one extension can't be redirected to another's.
- Screen Preview: `SFLDROP`/`SFLFOLD` (the subfile fold/truncate toggle key) now shows in the function-key legend — synthesizing a description ("Expand/Collapse Subfile") when the key has none of its own, which real DDS doesn't require. Shown apart from the regular keys, after a `|` separator, in blue, filled when the subfile is currently folded.
  - Previewing the **subfile-control (header) record**: starts in whichever state the DDS keyword declares (`SFLDROP` → truncated, `SFLFOLD` → folded; both on the same key → folded wins, matching the reference), and the legend key is clickable to toggle between them, simulating the real 5250 behavior — including the truncated form correctly showing proportionally more subfile-page rows than `SFLPAG`, since each takes one line instead of several.
  - Previewing the **subfile detail record itself**: always shown fully folded, regardless of the keyword, so every field and constant stays visible and editable — the legend key is disabled there, since toggling it would make normally-hidden rows draggable without the same safety net the header's (non-interactive) view has.
  - Also fixed along the way: the function-key legend only ever looked at the record being previewed directly, so previewing a subfile detail record on its own showed none of its `SFLCTL` header's CA/CF keys, even though both preview together as one screen.
- A **Subfile Drop/Fold** command on subfile control (SFLCTL) records: right-click and pick it for a summary menu listing `SFLDROP`/`SFLFOLD` with their current command key and any conditioning indicator (or "not set"), each with its own change/remove buttons — same style as Editing Keywords and Validity Checks.
### Changed
- Schema Tree: icons now use VS Code's native codicons (`ThemeIcon`) instead of emoji, rendering consistently across color themes and platforms.
- Schema Tree: the "Indicators" and "Attributes" subnodes no longer appear — at any level (file, record, field, or constant) — when there's nothing under them, instead of showing as a non-expandable, empty node.
### Removed
- Schema Tree: the Move Field/Constant Left/Right (1)/(5) inline tree buttons — dragging a field or constant directly in the Screen Preview already covers the same repositioning, making the dedicated buttons redundant.
### Fixed
- Add Validity Check: `VALUES` accepted any text typed into it with no validation, allowing invalid DDS to be written — e.g. mixing a quoted character value with a bare number (`VALUES('A' 'B' 55)`) on a character field. Each value is now validated against the field's type and length as you type: character fields require single-quoted values no longer than the field itself, numeric fields require plain unquoted numbers, and `VALUES` is no longer offered on a floating-point field (not allowed in DDS).
- Add Field / Add Constant: adding a field or constant to a subfile detail (SFL) record never checked for overlap with its SFLCTL header's own content when done from the tree's "Add Field"/"Add Constant" commands (absolute position or relative to an existing element) — only the Screen Preview's click-to-place enforced it. Both now refuse a row that's occupied by the header, the same way the preview already did.
- Screen Preview: when a subfile pair sits in a shared `WINDOW()`, the header-overlap check was off by the window's own origin row — depending on the fix in between, this either wrongly blocked a row that was actually free right below the header, or let a field be dragged back up into the header. The check and the drag boundary now agree on the same coordinate frame.
- Parser: reverted a row/column swap that had been silently applied to every field and constant inside a subfile detail (SFL) record since v0.3.2. It was meant to correct a subfile positioning bug at the time, but actually misread the DDS reference — real DDS source has every field on one subfile line sharing the same row and differing only in column, exactly as the raw source columns already say, no swap needed. Left unnoticed, it corrupted the row/column read (not written) by Change Position, Center, Copy Field, Copy Constant, Sort Elements, Fill Constant, Window Resize, and the tree's own field/constant description text for any element inside a subfile — only the Screen Preview happened to keep rendering correctly, because it had separately grown its own local workaround for the same swap. Both the swap and that workaround are now gone.

## [1.5.0] - 2026-09-09
### Added
- Preview: an active `SFLMSG()` on a subfile control record (SFLCTL) is now shown on the message line during indicator simulation, the same way `ERRMSG()` already is — respecting ERRMSG's priority over SFLMSG and requiring `SFLDSP` to be in effect, per the DDS reference.
- Preview: selecting a field with a validity check now also shows it (e.g. `VALUES(0 2 4 5 7 8)`) in the selection bar, alongside its name and position.
- Add Validity Check: replaced with a summary menu showing all three mutually exclusive keywords (RANGE/COMP/VALUES) and whichever one is currently set, each with its own change (✏️) and remove (🗑️) button — instead of the old "Add more/Replace all/Remove all" flow, which allowed invalid DDS (e.g. a duplicate `VALUES`, or `VALUES` together with `RANGE`). Setting one now automatically replaces whichever of the three is already in effect; changing an existing one pre-fills its current value.
- Add Error Messages: replaced with a summary menu listing every existing `ERRMSG`, each with its own change/remove buttons, plus "Add error message..." and "Remove all" — unlike validity checks, a field can legitimately carry several `ERRMSG`s, each gated by its own indicator.
- Add Indicators: replaced the flat "Add AND/Add OR/Modify/Remove a group/Replace all/Remove all" picker with a summary menu listing every OR'd condition, each with its own modify/remove buttons, plus "Add OR condition..." and "Remove all".
### Fixed
- Remove/Replace All Attributes (and the equivalent commands for colors, keys, error messages, and validity checks): removing/replacing on one constant could also strip attributes off unrelated constants later in the same record — the scan used to find where an element's attributes end didn't recognize the next constant's own row/column as a boundary.

## [1.4.1] - 2026-09-05
### Fixed
- Preview: window title (`WDWTITLE`) and border (`WDWBORDER`) stopped rendering — a regression from 1.4.0's multi-keyword-per-line parsing fix. Its keyword tokenizer didn't handle keywords with nested parentheses, e.g. `WDWTITLE((*TEXT '...') *TOP)` or `WDWBORDER((*COLOR BLU) (*DSPATR RI))`, shredding them into fragments instead of keeping each as one attribute.

## [1.4.0] - 2026-09-04
### Added
- Preview: `EDTCDE(W)`/`EDTCDE(Y)` (date-slash editing) and `EDTCDE(X)`/`EDTCDE(Z)` are now recognized and rendered correctly, confirmed against real STRSDA — previously fell back to a generic, often wrong, numeric mask.
- Preview: the `DATE()` keyword (`*JOB`/`*SYS`, `*Y`/`*YY`) is now recognized as a system field, with or without `EDTCDE(Y)`/`EDTCDE(W)`.
- Preview: a floating currency symbol on `EDTCDE()` (e.g. `EDTCDE(J $)`) now adds its extra display position; asterisk fill now shows as `*` in place of the leading digit instead of a plain digit.
- Configuration: new "Date Separator" section (US `/` / European `-`) alongside Decimal Format, with "Fetch from IBM i" (reads `QDATSEP`) and reset.
### Fixed
- Preview: an `EDTCDE()`'s comma/sign/date/currency decoration only ever shows on an output field, confirmed against real STRSDA — an input-capable field now previews as if unedited instead of always applying the code's formatting.
- Parser: several keywords on one physical source line (e.g. `EDTCDE(3) DSPATR(HI) COLOR(RED)`) were read as a single combined value instead of separate keywords, breaking both the preview and Remove Color/Attribute/Editing Keywords for a field or constant written that way.
- Remove Colors / Remove Attributes / Remove Editing Keywords: removing one keyword sharing a line with others — or continued onto the next line via a trailing hyphen — could delete the sibling keywords too, or leave survivors stranded on a continuation line they no longer needed.

## [1.3.0] - 2026-09-02
### Added
- Preview: the "⋮ Actions" menu (single selection) now also offers Rename... (fields) / Edit Text... (constants), Indicators..., and — for fields — Validity Checks..., Editing Keywords..., and Error Messages..., delegating to the exact same tree commands (same prompts, validation, and confirmations as right-clicking the element in the tree). The preview now covers practically everything the tree's context menu offers for a single field or constant.
- Preview: a resizable constant now also gets a second drag handle on its *left* edge, growing/shrinking its leading blank padding (moving its start column back to keep the visible text in place) instead of only the trailing padding on the right — down to column 1, or a window's own left content edge. Not offered for a constant inside a subfile record.
- Add Editing Keywords: replaced with a single summary menu showing all three slots (EDTCDE/EDTWRD/EDTMSK) and their current value at a glance, each with its own set/change (✏️) and remove (🗑️) buttons — instead of the old "Replace/Remove, then pick a type" two-step flow. Picking EDTCDE/EDTWRD is now a flat, type-to-filter list (no more category separators). Changing an existing EDTWRD/EDTMSK pre-fills the input with its current value; starting a new EDTWRD pre-fills a blank template already sized to the field, satisfying the "N digit positions" rule from the start. Setting EDTCDE/EDTWRD automatically drops the other (they're mutually exclusive in DDS) while keeping any existing EDTMSK; removing the base takes its EDTMSK with it.

## [1.2.0] - 2026-08-31
### Added
- Preview: the decimal point and thousands-separator convention used for `EDTCDE()`-edited numeric fields is now configurable — US (`1,000.00`, the previous fixed behavior) or European (`1.000,00`) — from a new "Decimal Format" section in the "⚙ Configuration" panel. A "Fetch from IBM i" button reads it straight from the connected IBM i's `QDECFMT` system value (both `1` and `J` map to European); a "Reset to Default" button restores US. Saved in the extension's own storage, applying immediately to any open preview panel.
### Fixed
- Preview: a numeric field with no `EDTCDE`/`EDTWRD` (blank Type with decimal positions given, or explicit type `S`) didn't reserve the extra trailing position IBM i itself adds for the sign on an input-capable signed-numeric field — e.g. a 1,0 field showed as a single digit instead of digit + `-`, confirmed against real STRSDA. Input-capable `Y`/`N` fields with decimal positions now correctly get an extra position for the decimal point instead (never a sign); output-only fields are unaffected, matching the DDS reference.

## [1.1.1] - 2026-08-28
### Fixed
- Preview: the `EDTCDE` thousands-separator table had commas alternating per individual code instead of per pair (1&2, A&B, J&K, N&O should show separators; 3&4, C&D, L&M, P&Q should not) — `EDTCDE(K)` (and 2/3/B/C/L/P) rendered with no thousands separator at all. (Issue #77)
- Preview: `EDTCDE(N/O/P/Q)` weren't recognized at all, so no decimal point/comma/sign width was reserved for them. Now supported, with the minus sign correctly reserved leading (before the first digit), unlike J/K/L/M which reserve it trailing — confirmed against real STRSDA.
- Preview and Add Editing Keywords: a numeric field with a blank Type column (position 35) — the default, most common way to define a plain zoned-numeric field, without an explicit type letter — was misdetected as alphanumeric, showing letter placeholders instead of digit ones, and could be blocked from getting an edit code/word.
- Add Editing Keywords: the `EDTCDE` picker's descriptions mislabeled the comma/no-comma distinction between paired codes as a decimals/no-decimals distinction.

## [1.1.0] - 2026-08-26
### Added
- Preview: the "⋮ Actions" menu now offers Copy (click a spot in the preview to place a copy of the selected field/constant, keeping its attributes/colors/indicators, within the same record) and Delete, alongside Add Color/Add Attribute. With more than one element selected, Add Color/Add Attribute/Delete apply to all of them at once.
- Preview: toolbar buttons regrouped into a single row that moves together whenever something's selected, so the selection info has room; "Indicators" always stays on its own line.
- Preview: selecting a single field now shows its length/decimals inline instead of a generic "field selected".
### Fixed
- Add Editing Keywords: `EDTMSK` could be applied to an output-only field; it's now restricted to input-capable fields (usage I/B), matching DDS.
- Display-format conditioning (`*DS3`/`*DS4`) on a `WINDOW`/`WDWTITLE`/`SFLPAG`/`SFLSIZ` line was written one column too early, and could condition the primary display size explicitly — both invalid DDS (confirmed by CPD7410/CPD7606 at compile time). Fixed across window resize/move, window title, new record creation, and Add Buttons.
- Add Field / Add Constant (tree): position was validated against the whole file's declared size instead of a window record's own (usually smaller) content area.
- Field/record names starting with `@`, `#`, or `$` were rejected — DDS allows them as the first character.

## [1.0.1] - 2026-08-24
### Fixed
- Preview: window border/content positioning corrected to match real STRSDA.
- A window can no longer be positioned at row 1 and column 1 at the same time, matching STRSDA.
- Preview: fixed a case where a field/constant dragged inside a window couldn't be moved back to its original position.

## [1.0.0] - 2026-08-22
### Added
- Preview: background color, the 7 DDS `COLOR()` colors (blue, red, white, green, turquoise, yellow, pink), and the referenced-field marker color are now configurable, instead of being fixed — useful for personal color preferences and for contrast/accessibility. A new "⚙ Configuration" button in the preview toolbar (disabled while Focus mode is on) opens a small panel to pick each one visually (native color picker, no hex typing), with a reset-to-default button per color and one for all of them at once — also available as the "DSPF Edit: Configure Preview Colors..." / "...Reset Preview Colors to Default" commands. Saved in the extension's own storage (not a VS Code setting), so changes persist without cluttering Settings, and apply immediately to any open preview panel. Defaults match the previous fixed colors.
### Changed
- No longer marked as a Preview extension. After many releases, deep DDS/STRSDA-accuracy work, and real user feedback, DSPF-edit is stable enough to drop the label.
### Fixed
- Add Color: its color/action pickers and indicator input could close themselves immediately after opening — most noticeable on trackpads — instead of staying open like every other interactive command in the extension. They now set `ignoreFocusOut`, matching the rest.

## [0.18.0] - 2026-08-20
### Added
- Preview: single- and multiple-choice selection fields (`SNGCHCFLD`/`MLTCHCFLD`) now render their `CHOICE()` options as "`N.` text" next to the field itself, laid out per the field's own `*NUMCOL`/`*NUMROW`/`*GUTTER` parameters (defaulting to a single vertical column when none are coded) — confirmed against STRSDA.
- Preview: a window's border now reflects its actual `WDWBORDER()` keyword (file-level and/or record-level, combined per the DDS reference) — its real color, display attributes (reverse image, high intensity, underline, blink), and its 8 border characters — instead of a plain decorative rectangle. Falls back to DDS's own defaults (blue, `.`/`:`) when none is coded.
- Preview: a window's `WDWTITLE()` now inherits the border's color/display attributes when it doesn't specify its own, matching real DDS behavior.
- Preview: fields and constants can now be resized by dragging a small triangular handle on their right edge — a field's length is written directly; a constant grows/shrinks its trailing blank padding, never its visible text. Windows use the same handle shape for their own corner resize.
- Fill Constant with Characters: the total size can now be picked from another field/constant instead of typed by hand — aligned to end where a same-row one begins, or to match the width of one on another row (e.g. lining up a column of menu options).
### Fixed
- Preview: a window title's default alignment now follows the DDS reference (left-aligned in the bottom border, centered in the top) instead of always centering.
- Add Editing Keywords: adding `EDTCDE`/`EDTWRD` to a signed-numeric (S) field left it as type S, which DDS does not allow together with an edit code or edit word — the generated source failed to compile with CPD7554. The field's type is now automatically upgraded to numeric-only (Y) when the editing keyword is added, matching STRSDA's own behavior.
- Center Constant/Field On Screen: on a file declaring more than one display size, always centered against the default (first-declared) size's width, even while previewing a different one — e.g. always 80 columns on a *DS3/*DS4 file, even with *DS4 (132 columns) selected in the preview. Centering from the preview now uses the size actually being previewed; from the tree, it asks which declared size to use.
- Add Buttons: on a file declaring more than one display size, always laid buttons out for the default (first-declared) size, regardless of which one was intended, and wrote them unconditioned so they'd also show, mispositioned, on the other size(s). Now asks which declared size to lay the buttons out for, and conditions the generated lines on it.

## [0.17.1] - 2026-08-15
### Added
- Preview: new "Focus" button hides the source editor to work from the preview alone (tree view stays visible).
- Preview: toolbar reorganized into clearer rows (size/Focus, Format/Overlay/paging/selection, field/constant tools, Indicators).
- Preview: selecting a single field or constant now shows its position (and width, for constants).
- Tree view: records can be reordered by dragging one onto another — moves the whole record in the source. Blocked if it would break SFL/SFLCTL order.
### Fixed
- Error Message: adding several messages at once could produce invalid DDS when one of them needed a continuation line.
- Tree/preview could stop refreshing after an edit made while the preview panel had focus.
- Preview: some tree/preview actions could unintentionally undo "Focus" mode.
- Deleting a field/constant with indicators spanning multiple lines could leave invalid leftover lines behind; this also affected how existing indicators were read for Color/Attribute.
- Add Field: creating a numeric field with 0 decimal places could fail to compile (CPD7408).

## [0.17.0] - 2026-08-12
### Added
- Command Keys: adding a CAxx/CFxx now also checks the *other* level (the file, when adding to a record; every record, when adding at file level) and excludes any key number already used there from the picker, regardless of whether the type matches — prevents generating a record whose effective key set defines the same key number as both CA and CF (or twice), which DDS won't compile.
- Preview: a function-key legend now always shows below the toolbar — one green-bordered `Fnn` badge per key actually available to the record being previewed (file-level + record-level CAxx/CFxx, record overriding file per key number, narrowed to the active display format). A key still shows even when its own indicator condition isn't currently met, so you can see at a glance that it's *defined*; it switches to solid (inverted) styling when it's actually active right now — correctly handling more than one indicator-conditioned alternate per key number (AND/OR), and hovering shows its description.
- Preview: an active `ERRMSG()` on a `WINDOW` record now shows on the window's own reserved message line (its last content row) instead of always at the bottom of the physical screen — matching the DDS `WINDOW` keyword's `MSGLIN`/`*NOMSGLIN` parameter (a window reserves its own message line by default; `*NOMSGLIN` is what opts out and sends it to the display's normal message line instead).
- Preview: the "Indicators" toggle and the active display format (e.g. *DS3) now persist across switching which record is previewed in the same panel, instead of resetting back off/default every time.
### Fixed
- Command Keys / Preview: a CAxx/CFxx description longer than 25 characters — legitimately allowed by DDS, spilling onto a continuation line in the source — was silently dropped from both the "current key commands" list and the preview's function-key legend. The reading regex incorrectly reused the 25-character cap that's only meant to apply when this tool itself creates a *new* key command.
- Preview: the display-format dropdown (the *DS3/*DS4 selector) could end up blank instead of showing a real selection — it now keeps the previously-selected format across record switches, but wasn't falling back when that format no longer applied (e.g. after switching to a different file, or a live edit removed a DSPSIZ format from the current one).
- Preview: the panel went blank after being dragged to a different editor group — VS Code was tearing down its live content whenever it became hidden (which moving it briefly does) and nothing re-rendered it on return; the panel now keeps its content alive in the background (`retainContextWhenHidden`).

## [0.16.0] - 2026-08-11
### Added
- Multi-size (DSPSIZ) awareness across creation and editing: when a display file declares more than one screen size (e.g. `DSPSIZ(24 80 *DS3 27 132 *DS4)`), the extension now keeps every declared size correct instead of only ever acting on the first one.
  - New Record / Change Window Size: creating or resizing a WINDOW now generates one `WINDOW()` line per declared size — same rows/columns, position recalculated to fit each screen — instead of a single line silently reused (and often mispositioned) on every size.
  - Change Window Title: edits the title line that actually matches the size being worked on, asking which one when invoked from the tree and the record declares more than one.
  - Preview: dragging/resizing/centering a window, or adjusting a subfile's SFLPAG/SFLSIZ, while a specific size is selected in the preview's format switcher no longer silently changes the other declared size too — the first time a shared, unconditioned line is edited this way, it's split into one explicit line per declared size, and only the one being viewed changes.
  - New "Add Display Size" command (right-click the file in the tree) adds the second standard size (*DS3/*DS4) to a file that currently declares only one, rewriting its DSPSIZ specification in place. Existing windows/subfiles keep applying to the new size unchanged (DDS's own "unconditioned line applies everywhere" rule) until adjusted per size from the preview. Removing a declared size isn't supported yet.
  - Change Position: a field/constant's row/column bounds are now validated against the smallest declared size, not just the first one, so a position stays reachable regardless of which size is active.

## [0.15.0] - 2026-08-11
### Added
- Indicators: full support for DDS's AND/OR conditioning — previously only a single line's worth (up to 3 ANDed) was read or editable, and OR'd conditions were silently ignored.
  - Parser: reads indicator-only continuation lines (position 7 `A`/blank to extend an AND group beyond 3, `O` to start a new OR'd group), up to DDS's own limits (9 ANDed indicators per condition, 9 OR'd conditions).
  - Tree view: an OR'd condition is now shown grouped into its ANDed sub-conditions instead of one flat, misleading list; hovering a conditioned field/constant/attribute shows the full condition as a tooltip (e.g. `51 AND NOT 61 AND 53  OR  52`).
  - Preview: indicator simulation (on/off toggles) now evaluates AND/OR conditions correctly instead of treating every indicator as ANDed together.
  - "Indicators" command: add a 4th+ ANDed indicator (continuation lines are generated/removed automatically), add or remove a whole OR'd condition, or edit indicators within a specific one when there's more than one.

## [0.14.2] - 2026-08-09
### Fixed
- Tree view: a record created in a brand-new DSPF source (one that started out with zero records) didn't show up in the records list until the source was closed and reopened — the per-document record filter seeded itself empty on that first parse and never learned to include anything added afterward.
- Parser/Preview: subfile record formats generated by SDA/RDI often carry the `SFL` keyword on its own line, separate from the record format name line, instead of on the same line. The parser only recognized `SFL` when it was on the record's own line, so those subfiles' fields rendered stacked vertically in the preview instead of side-by-side as subfile columns.

## [0.14.1] - 2026-08-01
### Fixed
- Parser: `REFFLD()`'s field name can be qualified with a record format (`REFFLD(record-format-name/field-name [library-name/]file-name)`), needed to disambiguate a field name that exists in more than one format of the referenced file. This qualification wasn't parsed correctly — the whole "format/field" text was used as the field name, which then never matched an actual database column, breaking resolution against IBM i entirely. Add/Edit Field's "Referenced Field" flow now also has a dedicated (optional) step for the record format, separate from the field name.
- Add Editing Keywords: `EDTCDE`/`EDTWRD`/`EDTMSK` were always rejected as "not a numeric field" on a referenced field, even after its real type had been resolved from IBM i (via "Resolve Referenced Field") — the check only ever looked at the field's own DDS source type, which is blank for a referenced field. It now uses the resolved type/length/decimals when available, and the warning explains when it's the type that's still unresolved rather than the field genuinely being non-numeric.
- Preview: a field with `EDTCDE()` rendered as a plain, unformatted placeholder (e.g. `66666666`) instead of showing the thousands separators/decimal point/sign a real edited numeric field displays — only `EDTWRD` was accounted for. The preview now derives an equivalent mask from the standard DDS edit-code table (1-4, A-D, J-M).
- Parser: fixed incorrect handling of multi-line constants (text continued across several source lines with a `-`) — depending on how the source line was formatted, the continuation could be missed or left embedded in the resulting text instead of being stripped out cleanly.
- Delete Field/Constant: if the following field/constant in the record had its Line/Position coded relative to the deleted one (DDS's relative record format — a blank Line, or a Position written as `+n`), deleting it silently re-anchored that following element to whatever now precedes it, moving it on screen. It's now materialized to an explicit absolute position first, matching what Move Field/Constant already does for an inherited row.
- Preview: deleting the only field/constant in a record that carried any conditioning indicators left the indicator toggle buttons for those indicators showing in the preview's indicator bar, instead of clearing along with it — a stale-refresh bug in the webview's own script, not the parser.
- Preview: adjusted the `COLOR(BLU)` shade to match the IBM i Access Client Solutions (ACS) 5250 terminal more closely.

## [0.14.0] - 2026-07-30
### Added
- New "Resolve Referenced Field" action for referenced fields (`REFFLD`/position-29 `R`, which carry no type/length in the source): a button on the field — and a "Resolve All Referenced Fields" command, also reachable from a new status bar item — queries the connected IBM i, via the [Code for i](https://marketplace.visualstudio.com/items?itemName=HalcyonTechLtd.code-for-ibmi) extension, for the referenced database field's real type/length/decimals. Works for both native physical/logical files and SQL-created tables (which can have different long and short column names). Once resolved, the field shows its real type/length in both the tree and the preview (rendered like a normal field, tinted the reference color only when it carries no `COLOR()`/`DSPATR()` of its own). Cached per document until it's closed, or re-resolved on demand from the same button. Requires Code for i to be installed and connected; shows a clear message otherwise.
- A status bar item shows how many referenced fields in the current document are still pending resolution.
- Preview: support for the `CNTFLD(n)` keyword — a field too long to fit on one line now wraps across multiple rows, `n` characters each, all starting at the field's original column, matching how RDi previews it. Centering such a field (`Center`/"↔") now uses its per-line width instead of its full declared length.
### Fixed
- Performance: two O(n²) hotspots in the parser (linking fields/constants to their record, and duplicate-field detection) made re-parsing a document — e.g. after moving a field in the preview — get dramatically slower as it grew larger. Both are now linear.
- Performance: checking whether a file is read-only before applying an edit did a live round-trip to the IBM i on every single edit while connected via Code for i. It's now cached per document.
- Referenced fields were missing the usual field context menu/inline actions (delete, copy, rename, etc.), due to a stricter internal check that didn't account for their new "pending"/"resolved" state.
- Parser: a field/constant positioned relative (`+n`) right after a bare system keyword (`DATE`, `TIME`, `USER`, `SYSNAME`) landed several columns too far left in the preview, overlapping the keyword's own placeholder — the parser was tracking the keyword's raw source-text length instead of its actual on-screen width when resolving the following `+n` position.
- Preview: dragging a `CNTFLD`-wrapped field failed with "the document may be read-only" — its wrapped lines all share one source line, and each was independently written back on drop, producing overlapping edits VS Code rejected outright.
- Preview: selecting a `CNTFLD`-wrapped field showed "N fields selected" (one per wrapped line) instead of being treated as the single field it is, hiding the "↔ Center"/"⋮ Actions" buttons as a result.

## [0.13.6] - 2026-07-29
### Fixed
- Parser: fields and constants positioned using DDS's relative record format (`+n` in the Position field, or a blank Line/Row meaning "same row as the previous field/constant") were misparsed as attributes and silently dropped, instead of being resolved to their actual screen position relative to the preceding field/constant.
- Move Field/Constant Left/Right (tree buttons): when a field/constant's row was inherited via the relative record format above, moving it horizontally updated the column but left the row blank in the source instead of writing it explicitly — unlike dragging in the preview panel, which already materializes both. Moving with the tree buttons now writes the row too.

## [0.13.5] - 2026-07-28
### Added
- Preview: a referenced field (`REFFLD`/position-29 `R`) now renders as a single marker character in a distinct color with a dashed box, instead of a guessed-width placeholder — its real type/length live in the external database field, which dspf-edit has no way to read.
### Fixed
- Add/Edit Field: problems with fields with length of 100 or more.
- Parser: field length was read back from only the last 2 characters of the length column. It has been fixed.
- Add Field: a referenced field (library/file/field) generated an invalid `REFFLD(library/file.field)` specification. Now generates the correct `REFFLD(field [library/]file)` format.
- Add Field: referencing a field required a library name, even though DDS itself makes it optional (falls back to the library list, `*LIBL`, when omitted). The prompt now accepts an empty library.

## [0.13.4] - 2026-07-27
### Fixed
- Parser: DDS comment lines with column 6 left blank (e.g. decorative `***...` banner blocks — the more common comment style, as opposed to `A*...`) were not recognized as comments. Such a line was misparsed as a field, and any file-level keyword coming after it (most notably `DSPSIZ()`) got attached to that phantom field instead of the file, silently falling back to the default screen size (24x80/*DS3) instead of the one actually declared. The same comment-detection fix was applied everywhere else it was used: locating insertion points for key commands, error messages, and file-level attributes.

## [0.13.3] - 2026-07-26
### Added
- Preview: selecting a field or constant now shows a "Selection actions" bar in the toolbar strip (not floating over the canvas, so it never fights the drag gesture or gets cramped by a single-character constant) — a one-click "↔ Center" button and a "⋮ Actions" menu (Add Color..., Add Attribute...), reusing the tree's own commands against the selected element.
- Preview/Center: the DDS system keywords `DATE`, `TIME`, `USER`, and `SYSNAME` now render with their real on-screen appearance (`DD-DD-DD`, `TT:TT:TT`, `UUUUUUUUUU`, `SSSSSSSS`), whether coded as a field's name or bare (unquoted) in a constant's position; "Center" now centers them using that real display width instead of the raw, misleadingly short source length.
- Preview: fields and constants can now be multi-selected (Ctrl/Cmd+click) and dragged together as one group, writing every new position back in a single edit; the selection bar reads "N fields/constants selected", and only offers "↔ Center"/"⋮ Actions" when exactly one item is selected.
- "Add Field" now offers a quick flow — just kind+usage (Alphanumeric/Numeric × Output/Input-Output/Input) and a size — that generates the same field STRSDA itself would (including an automatic `EDTWRD()` for numeric fields with decimals), reusing the same name/position steps as before; the full usage/referenced-field/type flow is still available behind a "More options..." entry for anything else (Hidden/Message usage, a referenced field, or another data type).
### Fixed
- Editing a read-only DDS source (e.g. an IBM i member opened in browse mode, or a read-only file) silently let every edit command (add/rename/move/delete field, constant, attribute, indicator, key command, window resize/title, subfile page size, and more) report success and modify the in-memory buffer, only to fail later with no warning when actually saving. Edits are now checked against the file's read-only status upfront, showing an immediate error instead.
- Preview: an output field with no explicit usage code (DDS's own default when left blank) showed its field name instead of the correct repeated-`O` placeholder text.
- Preview: a Date/Time/Timestamp (`L`/`T`/`Z`) field with no explicit length (DDS determines it automatically for these types) collapsed to a single placeholder character instead of its real fixed width (10/8/26).
- Parser: a bare system keyword (`DATE`, `TIME`, `USER`, `SYSNAME`) coded in a constant's position without quotes had its first and last character corrupted, since quote-stripping was applied unconditionally instead of only to actually-quoted text.
- Parser: two or more constants sharing identical text at different screen positions (e.g. blank/space "pixel" blocks used to build a colored logo out of `DSPATR(RI)` blocks) were silently collapsed down to just the first one found, since duplicates were detected by text alone instead of by source line.
- Preview: `DSPATR(HI)` with no explicit `COLOR()` rendered in the default green instead of white, unlike a real 5250 display.
- Preview: an alphanumeric field with a blank data-type column (DDS's own default — e.g. from the quick "Add Field" flow) showed numeric placeholder digits (6/9/3) instead of the correct usage letter (O/B/I).
- Preview: a numeric field carrying an `EDTWRD()` edit word showed a plain run of digits instead of the mask's actual picture (e.g. `99999999.99` instead of `9999999999`).

## [0.13.2] - 2026-07-25
### Added
- New "Add Commands Record" command (record context menu, shown only on subfile control (SFLCTL) records): creates a record right after the subfile for its function-key legend (e.g. "F3=Exit"). For window subfiles, moves the SFLCTL's own `WINDOW()` (and `WDWTITLE()`/`WDWBORDER()`) onto the new record and leaves a `WINDOW(record)` reference behind, so the legend shares the subfile's window.
- New "Page rows" +/- control in the preview toolbar for SFLCTL records: adjusts `SFLPAG()`, always keeping `SFLSIZ()` one more than `SFLPAG()`.
### Fixed
- An SFL/SFLCTL pair sharing a window (the SFLCTL declaring `WINDOW()` directly) could hide the other half's content behind the window's own opaque background in the preview.
- Dragging a window in the preview left the paired SFL/SFLCTL record's dimmed content static until the mouse was released, instead of moving live with the window.

## [0.13.1] - 2026-07-24
### Added
- New "Grid Dots" toggle in the preview toolbar: marks every empty character cell with a dot, to see spacing between fields/constants (and around a window's border) while designing a screen.
- Indicator simulation now resolves `ERRMSG()`: when its conditioning indicator is on, the message shows on the display's message line (in white), and the field it's attached to is shown in reverse image.
### Fixed
- A `WINDOW()` keyword followed by an optional parameter (e.g. `*NOMSGLIN`, `*RESTORE`, `*PRINT`) was not recognized, so the window wasn't rendered in the preview; moving/resizing a window with such a parameter, or editing its title, no longer strips it.

## [0.13.0] - 2026-07-23
### Added
- New "Preview Screen Layout" option: shows a green-screen-style visual preview of a record on a canvas. Also available as an inline button on record tree items, in addition to the context-menu option.
  - Supports COLOR() and DSPATR() keywords (HI, RI, BL, UL, CS, ND); input-capable fields are shown underlined.
  - Fields/constants can be dragged to reposition them, writing the new position back into the source.
  - "+ Field" / "+ Constant" buttons: click, then click a point on the screen to place a new field/constant there, reusing the same name/type/position prompts as the tree's "Add field"/"Add constant" commands. Validated against the record's own area (a window's content frame, or the SFL detail area below its header).
  - WINDOW records are drawn at their real screen position and can be resized/moved with the mouse; WDWTITLE is shown. Windows shared via WINDOW(record-name) are supported.
  - Clicking a window's title edits it directly; a "⋮" actions menu and a one-click "center horizontally" icon are also available on the window frame — all three only appear while hovering over the window.
  - Subfile (SFL/SFLCTL) records show all SFLPAG rows, and automatically preview their paired header/detail record; the detail rows can't be dragged up over the header's own content.
  - Any other record can be overlaid (dimmed) behind the one being previewed, to see how they compose.
  - Indicator simulation: toggle indicators on/off to preview conditional fields, constants, and attributes.
  - Display format switcher: for DSPF files declaring more than one DSPSIZ format (e.g. *DS3/*DS4), lets you switch between them — window positions/sizes, SFLSIZ/SFLPAG, and conditioned fields/constants/attributes are resolved for whichever format is active. Locked when the file only declares one format.
  - The preview stays in sync with the schema tree selection in both directions.
  - The toolbar (size, display format, overlay, indicators, add buttons) is laid out as a single, compact row.
- New "Change Window Title" command (record context menu) to add, edit, or remove a window's WDWTITLE(), with horizontal alignment (*LEFT/*CENTER/*RIGHT) and vertical position (*TOP/*BOTTOM); also editable directly from the preview.
### Fixed
- Moving a field or constant left/right in a subfile (buttons in the schema view) wrote the new position into the wrong source columns.
- The "Add buttons" command placed buttons in column 1 for window records instead of column 2 (column 1 isn't usable inside a window).
- A line conditioned by a display format name (e.g. "*DS3") instead of indicators was misread as garbage indicator data.
- Without indicator simulation, mutually-exclusive fields/constants/attributes conditioned by complementary indicators (e.g. one on "61", the other on "N61") could show at once instead of resolving to a single, deterministic state.
- Switching between two open DSPF files could leak one file's second DSPSIZ format size into the other's display-format selector.
- The record filter could silently hide a newly-added record with no obvious cause; it's now disabled (with a warning message) whenever a new record appears while the filter is active.
- The record filter could reset unpredictably back to "show all" whenever any record became invalid (e.g. renamed/removed), instead of just pruning the stale entry.
- "Hide all" in the record filter menu didn't actually hide records, only fields/constants.

## [0.12.3] - 2025-11-30
### Fixed
- When creating a new field, the horizontal position was being saved incorrectly in the source.

## [0.12.2] - 2025-11-29
### Fixed
- The movement of fields and constants in subfiles is corrected.
- Changes in record filtering.

## [0.12.1] - 2025-11-29
### Fixed
- The movement of fields and constants in subfiles is corrected.
- Changes in record filtering.

## [0.12.0] - 2025-11-28
### Added
- Now you can move a constant or field, one or five positions to the right or left using a button directly from the schema view.
### Fixed
- Changes to the filter button. It now maintains the filter by file (you can have a different filter applied to another file while they remain open).

## [0.11.0] - 2025-11-15
### Added
- Now you can filter the records you want to work with using the filter button. Also you can select if you want to see the constants or fields, or both.

## [0.10.5] - 2025-11-04
### Fixed
- The parser wasn't reading the first line of the document.

## [0.10.4] - 2025-11-03
### Fixed
- Problems adding new field on column > 80 position.

## [0.10.3] - 2025-10-31
### Fixed
- Problems adding new field on column > 80 position.

## [0.10.2] - 2025-10-30
### Fixed
- Bad DSPSIZ parsing.

## [0.10.1] - 2025-10-03
### Fixed
- Record renaming was not working fine in all cases.

## [0.10.0] - 2025-10-03
### Added
- New rename option for fields and records (button and menu option).

## [0.9.1] - 2025-10-03
### Fixed
- The extension no longer validates whether a constant fits on the screen. Constants that don’t fit can now be viewed by resizing the window.

## [0.9.0] - 2025-09-28
### Added
- Ability to remove a constant or field attribute from the DDS.

## [0.8.0] - 2025-09-21
### Added
- Ability to remove a constant or a field from the DDS.

## [0.7.3] - 2025-09-20
### Fixed
- Corrected navigation when clicking on the attributes.

## [0.7.2] - 2025-09-20
### Fixed
- Issue inserting keyword WSFLRRN in subfile records.
- "Buttons" cannot be inserted in records with SFL keyword.

## [0.7.1] - 2025-09-19
### Refactored
- Internal refactoring and code cleanup.
### Fixed
- 3-digit rows/columns were not being parsed correctly.
### Changed
- Improved subfile record creation (both regular and window subfiles):
  - Every subfile is created with a control record (header), and the subfile record (detail).
  - The control record is created with: SFLSIZ, SFLPAG, OVERLAY, RTNCSRLOC, SFLCSRRRN, SFLDSP, SFLDSPCTL,
    SFLCLR and SFLEND. SFLDSP, SFLDSPCTL, SLFEND with N80 indicator, and SFLCLR with 80 indicator.
    Also some hidden fields are added: NRR, NBR, WSRECNAM, WSFLDNAM, and WSFLRRN.
    (all this will be configurable in future versions).

## [0.7.0] - 2025-09-14
### Added
- Ability to copy a Field/Constant to a different record or to a different position within the same record.  
  If copying a field, you must provide a new name if one with the same name already exists in the destination record.
### Fixed
- Fixed an issue when sorting items in a record that had hidden fields. These fields now appear first in the sort order.

## [0.6.2] - 2025-09-10
### Fixed
- Fixing resizing again.

## [0.6.1] - 2025-09-09
### Fixed
- Internal fixes. Refactoring.
- The resizing function was not working correctly.

## [0.6.0] - 2025-09-08
### Added
- New feature: Sort elements function for sorting constants/fields in a record by row, column or row/column, ascending or descending.
### Fixed
- You can add a new record from the "File" node, or from the "Records" node.

## [0.5.1] - 2025-09-08
### Fixed
- Field size validation is fixed when editing fields.

## [0.5.0] - 2025-09-06
### Added
- The extension can be launched from a separate icon in the activity bar.
- The extension remembers the last opened DDS display file source and allows you to use other extensions simultaneously (for example, you can use IBM i Renderer without losing the DDS structure on the screen).
### Fixed
- Problems adding a new field.

## [0.4.3] - 2025-09-04
### Fixed
- Now only the field length is requested when the type requires it.

## [0.4.2] - 2025-09-02
### Fixed
- Internal changes.

## [0.4.1] - 2025-08-31
### Fixed
- The WDWTITLE opcode was not split properly if the line exceeded column 80.

## [0.4.0] - 2025-08-30
### Added
- Possibility of window resizing.

## [0.3.4] - 2025-08-30
### Fixed
- If the field has no attributes, the first attribute is set on the same line in the DDS.
- If the field has no attributes, the first color is set on the same line in the DDS.
- If the field has no attributes, the first editing keyword is set on the same line in the DDS.
- The calculation of the position of the "buttons" in "add-buttons" has been modified.
- The function "isAttributeLine" has been improved.

## [0.3.3] - 2025-08-28
### Fixed
- Internal parser bug fixes.

## [0.3.2] - 2025-08-26
### Fixed
- SFL field column/rows bad configured.

## [0.3.1] - 2025-08-25
### Fixed
- WDWTITLE command fix.

## [0.3.0] - 2025-08-24
### Added
- Add fields in relative position to another field/constant on screen.

## [0.2.1] - 2025-08-23
### Added
- Fill constants with characters.

## [0.2.0] - 2025-08-23
### Added
- Add constants in relative position to another on screen.

## [0.1.1] - 2025-08-22
### Fixed
- When creating a new window record, it's not positioned in the correct row. It moves up two positions.
- When creating "buttons," in a window, the starting position should be 1. In records, it should be 2. 

## [0.1.0] - 2025-08-21
### Added
- Add / Modify / Remove indicators on constants/fields.
- Add / Modify / Remove indicators on constants/fields attributes.

## [0.0.1] - 2025-08-19
### Added
- Initial release of **DSPF-edit** (Preview).
- Visual schema explorer for DDS display files.
- Navigation between DDS file, records, fields and constants.
- Context menu actions:
  - Create/edit constants and fields.
  - Copy/delete records.
  - Apply colors, attributes, and indicators.
  - Add command keys and validity checks.
  - Add error messages.
- Support for display size and positioning of elements.
